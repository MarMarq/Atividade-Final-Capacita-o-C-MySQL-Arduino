﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1_AF01_21
{
    public partial class Form1 : Form
    {

        SerialPort portaSerial = new SerialPort();
        private GlobalDB bancoDados = new GlobalDB();

        bool STATUS_LUZES = false;  // LUZES APAGADAS
        bool STATUS_PORTAO = false; // PORTAO FECHADO
        string temp = "";
        string UltimoEventoLuzes = "";
        string UltimoEventoPortao = "";


        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtUsuario.Text == "")
                MessageBox.Show("Campo USUÁRIO OBRIGATÓRIO!!", "ERRO!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else

            if (!portaSerial.IsOpen)
            {
                try
                {
                    portaSerial.PortName = textBox1.Text.ToString();
                    portaSerial.BaudRate = 9600;
                    portaSerial.Open();
                    button1.Enabled = false;
                    button2.Enabled = true;
                    txtUsuario.Enabled = false;

                    portaSerial.DataReceived += new SerialDataReceivedEventHandler(serialPort1_DataReceived);

                    portaSerial.Write("TESTE");

                    label3.Text = "STATUS: CONECTADO";

                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (portaSerial.IsOpen)
                {
                    portaSerial.Close();
                    label3.Text = "STATUS: DESCONECTADO";
                    txtUsuario.Enabled = true;
                    button1.Enabled = true;
                    button2.Enabled = false;
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            button1.Enabled = true;
            button2.Enabled = false;

        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            SerialPort sp = (SerialPort)sender;
            string incomString = sp.ReadLine();

            /********************************************
             *  Descrição da PALAVRA: EEE;LLL;TTT;PPP;  *
             *                         |   |   |   |    *  
             *  EvLocal ---------------+   |   |   |    *
             *  dadoLuz -------------------+   |   |    *
             *  temp --------------------------+   |    *
             *  dadoMot ---------------------------+    *
             ********************************************  
            ____________________________________________
             Sinais ENVIADOS: Arduino --> PC
            --------------------------------------------
            EL0 - Nao ocorreu EVENTO LOCAL
            EL1 - Ocorreu EVENTO LOCAL

            M1i - PORTAO FECHADO INICIAL        ERA M0i
            M0C - PORTAO ABRINDO em CURSO       ERA M1C
            M1C - PORTAO FECHANDO em CURSO      ERA M0C
            M1R - PORTAO FECHADO REMOTAMENTE
            M0R - PORTAO ABERTO REMOTAMENTE

            L1R - LUZES LIGADAS REMOTAMENTE
            L0R - LUZES DESLIGADAS REMOTAMENTE

            L1L - LUZES LIGADAS LOCALMENTE
            L0L - LUZES DESLIGADAS LOCALMENTE
            ____________________________________________
             Sinais ENVIADOS: PC --> Arduino (recebidos)
            --------------------------------------------
            LL - LIGAR LUZES REMOTAMENTE
            LD - DESLIGAR LUZES REMOTAMENTE

            AP - ABRIR PORTAO REMOTAMENTE
            FP - FECHAR PORTAO REMOTAMENTE
            */

            var str = incomString.Split(';');
            int len = str.Length;
            string slen = len.ToString();

            string str1 = "-------"; // TextBox2 --> LUZES ENTRADA
            string str2 = "-------"; // TextBox3 --> TEMPERATURA
            string str3 = "-------"; // TextBox4 --> PORTAO ENTRADA

            // str[0] --> // EVENTO LOCAL
            // str[1] --> // dadoLuz
            // str[2] --> // Temperatura
            // str[3] --> // dadoMot

            if (len > 3)
            {
                str2 = str[2]; // Temperatura
                temp = str[2];


                if (str[1] == "L0i")
                {
                    UltimoEventoLuzes = "Desligado INICIAL";
                    STATUS_LUZES = false;
                }

                if (str[3] == "M1i")
                {
                    UltimoEventoPortao = "Fechado INICIAL";
                    STATUS_PORTAO = false;
                }

                if (str[3] == "M0C")
                {
                    UltimoEventoPortao = "ABRINDO EM CURSO";
                }
                if (str[3] == "M1C")
                {
                    UltimoEventoPortao = "FECHANDO EM CURSO";
                }
                //-------------------------------------------------------------------------------------------------------
                if (str[0] == "ELL")
                {
                    if (str[1] == "L1L")
                    {
                        UltimoEventoLuzes = "Ligado LOCAL";
                        STATUS_LUZES = true;
                        bancoDados.cadastrar(txtUsuario.Text.ToString(), temp, "LUZES", "ACENDEU_LOCAL");
                    }
                    if (str[1] == "L0L")
                    {
                        UltimoEventoLuzes = "Desligado LOCAL";
                        STATUS_LUZES = false;
                        bancoDados.cadastrar(txtUsuario.Text.ToString(), temp, "LUZES", "APAGOU_LOCAL");
                    }
                }
                else
                {
                    if (str[1] == "L1L")
                    {
                        UltimoEventoLuzes = "Ligado LOCAL";
                        STATUS_LUZES = true;
                    }
                    if (str[1] == "L0L")
                    {
                        UltimoEventoLuzes = "Desligado LOCAL";
                        STATUS_LUZES = false;
                    }
                }
                    //-------------------------------------------------------------------------------------------------------
                    if (str[0] == "ELP")
                {
                    if (str[3] == "M1L")
                    {
                        UltimoEventoPortao = "Fechado LOCAL";
                        STATUS_LUZES = true;
                        bancoDados.cadastrar(txtUsuario.Text.ToString(), temp, "PORTAO", "FECHADO_LOCAL");
                    }
                    if (str[3] == "M0L")
                    {
                        UltimoEventoPortao = "Aberto LOCAL";
                        STATUS_LUZES = false;
                        bancoDados.cadastrar(txtUsuario.Text.ToString(), temp, "PORTAO", "ABERTO_LOCAL");
                    }
                    //-------------------------------------------------------------------------------------------------------
                }
                    else
                { 

                    //-------------------------------------------------------------------------------------------------------
                    if (str[3] == "M1L")
                    {
                        UltimoEventoPortao = "Fechado LOCAL";
                        STATUS_LUZES = true;
                    }
                    if (str[3] == "M0L")
                    {
                        UltimoEventoPortao = "Aberto LOCAL";
                        STATUS_LUZES = false;
                    }
                    //-------------------------------------------------------------------------------------------------------
                }

                if (str[1] == "L1R")
                {
                    UltimoEventoLuzes = "Ligado REMOTO";
                    STATUS_LUZES = true;
                }

                if (str[1] == "L0R")
                {
                    UltimoEventoLuzes = "Desligado REMOTO";
                    STATUS_LUZES = false;
                }
              
                if (str[3] == "M1R")
                {
                    UltimoEventoPortao = "FECHADO REMOTO";
                    STATUS_PORTAO = false;
                }

                if (str[3] == "M0R")
                {
                    UltimoEventoPortao = "ABERTO REMOTO";
                    STATUS_PORTAO = true;
                }
                

            }


            // TextBox2 --> LUZES ENTRADA
            var threadParameters1 = new System.Threading.ThreadStart(delegate { UpDataTextBox2Safe(UltimoEventoLuzes); });
            var thread1 = new System.Threading.Thread(threadParameters1);
            thread1.Start();
            // TextBox3 --> TEMPERATURA
            var threadParameters2 = new System.Threading.ThreadStart(delegate { UpDataTextBox3Safe(str2); });
            var thread2 = new System.Threading.Thread(threadParameters2);
            thread2.Start();
            // TextBox4 --> PORTAO ENTRADA
            var threadParameters3 = new System.Threading.ThreadStart(delegate { UpDataTextBox4Safe(UltimoEventoPortao); });
            var thread3 = new System.Threading.Thread(threadParameters3);
            thread3.Start();

        }
        public void UpDataTextBox2Safe(string text)
        {
            if (textBox2.InvokeRequired)
            {
                Action safeWrite = delegate { UpDataTextBox2Safe($"{text}"); };
                textBox2.Invoke(safeWrite);
            }
            else
                textBox2.Text = text;
        }
        
        public void UpDataTextBox3Safe(string text)
        {
            if (textBox3.InvokeRequired)
            {
                Action safeWrite = delegate { UpDataTextBox3Safe($"{text}"); };
                textBox3.Invoke(safeWrite);
            }
            else
                textBox3.Text = text;
        }
        
        public void UpDataTextBox4Safe(string text)
        {
            if (textBox4.InvokeRequired)
            {
                Action safeWrite = delegate { UpDataTextBox4Safe($"{text}"); };
                textBox4.Invoke(safeWrite);
            }
            else
                textBox4.Text = text;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboOpcoes.Items.Add("NOME");
            comboOpcoes.Items.Add("DATA");
            comboOpcoes.Items.Add("HORA");
            comboOpcoes.Items.Add("EQUIPAMENTO");
            comboOpcoes.Items.Add("STATUS");


        }

        private void button3_Click(object sender, EventArgs e)
        {
            // NOTA: Prototipo --> cadastrar(string nome, string temp, string equip, string status)
            if (!STATUS_LUZES)
            {
                // As LUZES estão APAGADAS?
                // Então LIGAR LUZES
                portaSerial.Write("LL");
                UltimoEventoLuzes = "Ligado REMOTO";
                bancoDados.cadastrar(txtUsuario.Text.ToString(), temp, "LUZES", "ACENDEU_REMOTO");
            }
            else
            {
                // Se NÃO Então DESLIGAR LUZES
                portaSerial.Write("LD");
                UltimoEventoLuzes = "Desligado REMOTO";
                bancoDados.cadastrar(txtUsuario.Text.ToString(), temp, "LUZES", "APAGOU_REMOTO");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

            // NOTA: Prototipo --> cadastrar(string nome, string temp, string equip, string status)
            if (STATUS_PORTAO)
            {
                // O PORTAO está ABERTO?
                // Então FECHAR o PORTAO
                portaSerial.Write("FP");
                UltimoEventoPortao = "Fechado REMOTO";
                bancoDados.cadastrar(txtUsuario.Text.ToString(), temp, "PORTAO", "FECHOU_REMOTO");
            }
            else
            {
                // Se NÃO Então ABRIR o PORTAO
                portaSerial.Write("AP");
                UltimoEventoPortao = "Aberto REMOTO";
                bancoDados.cadastrar(txtUsuario.Text.ToString(), temp, "PORTAO", "ABRIU_REMOTO");
            }
        }

        private void btnListar_Click(object sender, EventArgs e)
        {
            listViewRegistros.Clear();
            ArrayList lista = bancoDados.listar();
            foreach (Object item in lista)
                listViewRegistros.Items.Add(item.ToString());
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            listViewRegistros.Clear();
            ArrayList lista = bancoDados.buscar(textBoxBusca.Text, comboOpcoes.Text);
            foreach (Object item in lista)
                listViewRegistros.Items.Add(item.ToString());
        }
    }
}
