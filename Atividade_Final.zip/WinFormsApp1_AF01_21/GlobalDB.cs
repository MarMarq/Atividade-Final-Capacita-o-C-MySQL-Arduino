﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace WinFormsApp1_AF01_21
{
    class GlobalDB
    {
        //Responsável pela conexão com banco de dados
        private MySqlConnection conexao;

        //Responsável pelas instruções à serem executadas
        private MySqlCommand comando;

        //Responsável por inserir dados em uma DataTable
        private MySqlDataAdapter adaptador;

        //Responsavel por ligar o Banco e controles com a propriedade DataSource
        private DataTable dataTabela;

        public GlobalDB()
        {
            //Estabelece os parâmetros para conexão com o BD
            conexao = new MySqlConnection("server=localhost; uid=root; pwd=Fu4bl3p!g;");
            conectarBD();

        }

        public void conectarBD()
        {


            //Abre a conexão com o BD
            conexao.Open();

            //Informa a instrução/comando SQL
            comando = new MySqlCommand("CREATE DATABASE IF NOT EXISTS bdarduino2;" +
                                        "use bdarduino2; ", conexao);   // bdarduino2 era bdarduino            

            //Executa a instrução no MySQL 
            comando.ExecuteNonQuery();


            //Informa outra instrução/comando SQL
            /*
             *      nome
             *      data
             *      hora
             *      temp
             *      equipo
             *      status
             */
            comando = new MySqlCommand("CREATE TABLE IF NOT EXISTS registros( " +
                                                    "id INTEGER AUTO_INCREMENT PRIMARY KEY, " +
                                                    "nome VARCHAR(50), " +
                                                    "data VARCHAR(12), " +
                                                    "hora VARCHAR(6), " +
                                                    "temp VARCHAR(5)," +
                                                    "equipo VARCHAR(30)," +
                                                    "status VARCHAR(30)); ", conexao);

            comando.ExecuteNonQuery();

            //Fecha a conexão com o Banco de Dados
            conexao.Close();
        }

        public void cadastrar(string nome, string temp, string equip, string status)
        {
            conexao.Open();

            comando = new MySqlCommand("INSERT INTO registros (nome, data, hora, temp, equipo, status) " +
                                       " values('" + nome + "', '" + DateTime.Now.ToString("dd/MM/yyyy") + "', '" +
                                        DateTime.Now.ToString("H:mm") + "', '" + temp + "', '" +
                                        equip + "', '" + status + "');", conexao);


            comando.ExecuteNonQuery();

            //Fecha a conexão com o Banco de Dados
            conexao.Close();
        }

        public string ultimoId()
        {
            string id = "";
            conexao.Open();

            comando = new MySqlCommand("SELECT MAX(id) AS maior FROM registros;", conexao);

            MySqlDataReader resultado = comando.ExecuteReader();

            if (resultado.HasRows)
            {
                resultado.Read();
                id = resultado["maior"].ToString();
            }

            conexao.Close();

            return id;
        }

        public void alterar(string id, string nome, string email, string telefone)
        {
            conexao.Open();

            comando = new MySqlCommand("SELECT * FROM registros where id=" + id + ";", conexao);

            MySqlDataReader resultado = comando.ExecuteReader();

            if (resultado.HasRows)
            {
                resultado.Read();
                string instrucao = "UPDATE registros set ";
                instrucao += "nome = '" + nome + ";";

                resultado.Close();

                comando = new MySqlCommand(instrucao, conexao);

                comando.ExecuteNonQuery();
            }

            conexao.Close();
        }

        public ArrayList consultar(string nome)
        {
            conexao.Open();

            comando = new MySqlCommand("SELECT * FROM registros where lower(nome) like '%" + nome.ToLower() + "%';", conexao);

            MySqlDataReader resultado = comando.ExecuteReader();

            ArrayList lista = new ArrayList();

            //Registro r = new Registro();

            /*
             *      nome
             *      data
             *      hora
             *      temp
             *      equipo
             *      status
             */

            if (resultado.HasRows)
            {
                while (resultado.Read())
                {
                    String item = null;
                    item += resultado["id"].ToString() + "\t - ";
                    item += resultado["nome"].ToString() + "\t -";
                    item += resultado["data"].ToString() + "\t -";
                    item += resultado["hora"].ToString() + "\t -";
                    item += resultado["temp"].ToString() + "\t -";
                    item += resultado["equipo"].ToString() + "\t -";
                    item += resultado["status"].ToString();
                    lista.Add(item);
                }
            }

            resultado.Close();
            conexao.Close();

            return lista;
        }
        //----------------------------------------------------------------------------------
        public ArrayList buscar(string nome, string target)
        {

            conexao.Open();

            if (target == "NOME")
                comando = new MySqlCommand("SELECT * FROM registros where lower(nome) like '%" + nome.ToLower() + "%';", conexao);

            if (target == "DATA")
                comando = new MySqlCommand("SELECT * FROM registros where lower(data) like '%" + nome.ToLower() + "%';", conexao);

            if (target == "HORA")
                comando = new MySqlCommand("SELECT * FROM registros where lower(hora) like '%" + nome.ToLower() + "%';", conexao);

            if (target == "EQUIPAMENTO")
                comando = new MySqlCommand("SELECT * FROM registros where lower(equipo) like '%" + nome.ToLower() + "%';", conexao);

            if (target == "STATUS")
                comando = new MySqlCommand("SELECT * FROM registros where lower(status) like '%" + nome.ToLower() + "%';", conexao);


            MySqlDataReader resultado = comando.ExecuteReader();

            ArrayList lista = new ArrayList();

            //Registro r = new Registro();

            /*
             *      nome
             *      data
             *      hora
             *      temp
             *      equipo
             *      status
             */

            if (resultado.HasRows)
            {
                while (resultado.Read())
                {
                    String item = null;
                    item += resultado["id"].ToString() + "\t - ";
                    item += resultado["nome"].ToString() + "\t -";
                    item += resultado["data"].ToString() + "\t -";
                    item += resultado["hora"].ToString() + "\t -";
                    item += resultado["temp"].ToString() + "\t -";
                    item += resultado["equipo"].ToString() + "\t -";
                    item += resultado["status"].ToString();
                    lista.Add(item);
                }
            }

            resultado.Close();
            conexao.Close();

            return lista;
        }
        //----------------------------------------------------------------------------------

        public ArrayList listar()
        {
            conexao.Open();

            comando = new MySqlCommand("SELECT * FROM registros ORDER BY id;", conexao);

            //Executa a consulta no banco de dados e retorna o resultado
            MySqlDataReader resultado = comando.ExecuteReader();

            ArrayList lista = new ArrayList();

            //Se houver linhas no resultado, significa que existem registros
            if (resultado.HasRows)
            {
                //Console.WriteLine("\n ***Listagem os Registros ***\n");

                //Laço de repetição responsável por percorrer cada linha do resultado
                while (resultado.Read())
                {
                    String item = null;
                    item += resultado["id"].ToString() + "\t - ";
                    item += resultado["nome"].ToString() + "\t -";
                    item += resultado["data"].ToString() + "\t -";
                    item += resultado["hora"].ToString() + "\t -";
                    item += resultado["temp"].ToString() + "\t -";
                    item += resultado["equipo"].ToString() + "\t -";
                    item += resultado["status"].ToString();
                    lista.Add(item);
                }
            }

            resultado.Close();
            conexao.Close();
            return lista;
        }

    }
}
